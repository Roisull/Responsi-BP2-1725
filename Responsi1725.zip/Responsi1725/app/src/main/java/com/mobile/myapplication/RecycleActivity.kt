package com.mobile.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class RecycleActivity : AppCompatActivity() {

    private var layoutManager:RecyclerView.LayoutManager?=null
    private var adapter:RecyclerView.Adapter<ProdukAdapter.ViewHolder>?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recycle)

        //set layout menjadi linear layout
        layoutManager = LinearLayoutManager(this)

        //instance Recycler View
        var rvProduk:RecyclerView = findViewById(R.id.rc_rc_item)

        //set layout utk recycler view
        rvProduk.layoutManager = layoutManager

        //call adapter dan set recycler sesuai adapter yg telah dibuat
        adapter = ProdukAdapter()
        rvProduk.adapter = adapter


    }
}