package com.mobile.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProdukAdapter:RecyclerView.Adapter<ProdukAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
    // declare dataset array
        private var foto = intArrayOf(R.drawable.image_1, R.drawable.image_2, R.drawable.image_3)
        private var nama = arrayOf("periksa hati", "periksa gigi", "periksa idung")
        private var desk = arrayOf("dijamin makin gila", "dijamin makin sakit", "dijamin gabisa napas")

        inner class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
            var itemFoto:ImageView
            var itemNama:TextView
            var itemDesk:TextView

            init {
                itemFoto = itemView.findViewById(R.id.item_foto)
                itemNama = itemView.findViewById(R.id.textView_judul)
                itemDesk = itemView.findViewById(R.id.textView_deskripsi)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.cardview_product,parent,false)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        TODO("Not yet implemented")
    }

    override fun getItemCount(): Int {
        TODO("Not yet implemented")
    }

}